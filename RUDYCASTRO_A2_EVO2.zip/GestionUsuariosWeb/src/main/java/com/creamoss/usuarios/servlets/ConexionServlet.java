package com.creamoss.usuarios.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/conexion")
public class ConexionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/Gestion_Usuarios";
    private static final String JDBC_USER = "maria@email.com";
    private static final String JDBC_PASS = "123456";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
            out.println("<h2>✅ Conexión exitosa a la base de datos</h2>");
            conn.close();
        } catch (ClassNotFoundException e) {
            out.println("<h2>❌ Error con el driver JDBC</h2>");
            e.printStackTrace(out);
        } catch (SQLException e) {
            out.println("<h2>❌ Error de conexión a la base de datos</h2>");
            e.printStackTrace(out);
        }
    }
}
