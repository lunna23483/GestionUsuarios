package com.creamoss.usuarios.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/Gestion_Usuarios";
    private static final String JDBC_USER = "maria@email.com";
    private static final String JDBC_PASS = "123456";

    // Mostrar el formulario
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Login</title></head><body>");
        out.println("<h2>Iniciar sesión</h2>");
        out.println("<form method='post' action='login'>");
        out.println("Correo: <input type='text' name='correo'><br><br>");
        out.println("Clave: <input type='password' name='clave'><br><br>");
        out.println("<input type='submit' value='Ingresar'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    // Procesar el login
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String correo = request.getParameter("correo");
        String clave = request.getParameter("clave");

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            String sql = "SELECT nombre FROM usuarios WHERE correo = ? AND clave = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, correo);
            ps.setString(2, clave);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String nombre = rs.getString("nombre");
                out.println("<h2>✅ Bienvenido/a, " + nombre + "</h2>");
            } else {
                out.println("<h2>❌ Usuario o clave incorrectos.</h2>");
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }
}



